fastcgi
=======

FastCGI Framework

Used as a backend for the [Web Engine](/odis-project/web-engine).
