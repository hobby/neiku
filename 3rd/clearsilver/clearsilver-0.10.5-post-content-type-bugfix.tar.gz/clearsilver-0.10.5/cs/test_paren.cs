<?cs def:test(a) ?>
VALUE:<?cs var:a ?>:
<?cs /def ?>
<?cs call:test("HELLO()") ?>

