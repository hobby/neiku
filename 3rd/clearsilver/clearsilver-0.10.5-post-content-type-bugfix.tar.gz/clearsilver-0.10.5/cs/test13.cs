
<?cs each:test = EvarTests ?>
  <?cs lvar:test ?>
<?cs /each ?>

<?cs lvar: CS_START + " alt:Foo " + CS_END + "bar" + CS_START + " /alt " + CS_END ?>
