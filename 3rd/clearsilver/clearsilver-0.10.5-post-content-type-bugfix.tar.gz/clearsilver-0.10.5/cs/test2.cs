
I'm in test2.cs

<?cs if:var ?>
  I'm in an if
<?cs /if ?>
wow2
