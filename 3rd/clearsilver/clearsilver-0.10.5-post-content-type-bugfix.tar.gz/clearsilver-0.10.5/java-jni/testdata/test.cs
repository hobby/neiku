Testing CS parse file...

<?cs set:Foo.Frank = "Beans" ?>

<?cs each:f = Foo ?>
  <?cs var:f ?>
<?cs /each ?>
